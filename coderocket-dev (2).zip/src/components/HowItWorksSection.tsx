import { Check } from 'lucide-react'

export function HowItWorksSection() {
  return (
    <div className="bg-white py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-blue-900 mb-4">
            HOW THE SEARCH WORKS
          </h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            Our Database Searches Billions Of Records, Including Dating Apps Like Tinder, Hinge, OkCupid, And Match.
          </p>
        </div>

        <div className="bg-sky-100 rounded-lg p-8 max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="flex items-start gap-3">
                <div className="bg-teal-400 rounded-full p-1 mt-1">
                  <Check className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-blue-900 mb-2">
                    ENTER THEIR NAME, EMAIL, OR PHONE NUMBER
                  </h3>
                  <p className="text-sm text-gray-700">
                    We will match their info to data from 120+ different apps
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-teal-400 rounded-full p-1 mt-1">
                  <Check className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-blue-900 mb-2">
                    IF WE FIND SOMETHING, WE DIG DEEPER
                  </h3>
                  <p className="text-sm text-gray-700">
                    The first search takes 30 seconds. If we find something, we keep digging for more
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-teal-400 rounded-full p-1 mt-1">
                  <Check className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-blue-900 mb-2">
                    INSTANTLY SEE YOUR FULL SEARCH RESULTS
                  </h3>
                  <p className="text-sm text-gray-700">
                    We show you all of their accounts, hidden legal records, and anything else we find
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-blue-900 rounded-lg p-6 text-white">
              <div className="space-y-6">
                <div>
                  <h3 className="font-bold text-teal-300 mb-2">Is My Search Private?</h3>
                  <p className="text-sm">
                    Yes! Your search is 100% private and secure. The person you search will not be notified.
                  </p>
                </div>

                <div>
                  <h3 className="font-bold text-teal-300 mb-2">How Long Does The Search Take?</h3>
                  <p className="text-sm">
                    You search will start instantly. If we find something, you will have a full report in under 2 minutes.
                  </p>
                </div>

                <div>
                  <h3 className="font-bold text-teal-300 mb-2">What If Nothing Comes Up After The Search?</h3>
                  <p className="text-sm">
                    We recommend you try all 3 searches for the best results. Starting a search for name, email, or phone number is <span className="font-bold">FREE</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}