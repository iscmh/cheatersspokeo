import { Button } from './ui/button'

export function FinalCTASection() {
  return (
    <div className="bg-blue-900 py-12">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl md:text-3xl font-bold text-teal-300 mb-4">
          DISCOVER THE TRUTH
        </h2>
        <p className="text-white text-lg mb-8 max-w-2xl mx-auto">
          Tap below to uncover the truth and get clarity instantly.
        </p>
        <Button className="bg-teal-400 hover:bg-teal-500 text-black font-bold py-4 px-12 text-xl rounded-lg">
          CHECK NOW
        </Button>
      </div>
    </div>
  )
}