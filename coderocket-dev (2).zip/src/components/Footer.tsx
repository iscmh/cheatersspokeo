export function Footer() {
  return (
    <footer className="bg-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex justify-center gap-6 mb-6">
          <a href="#" className="text-blue-900 hover:underline text-sm">Cookies</a>
          <a href="#" className="text-blue-900 hover:underline text-sm">Privacy Policy</a>
          <a href="#" className="text-blue-900 hover:underline text-sm">Contact</a>
        </div>
        
        <div className="text-center text-sm text-gray-600 max-w-4xl mx-auto mb-4">
          <p>
            The purpose of this update is to give you clarity in your relationship. With cheating and infidelity on the rise, knowing the truth matters now more than ever. We hope that using the spoiled dating app search helps you find out the truth about your partner. Starting your search is free.
          </p>
        </div>
        
        <div className="text-center text-xs text-gray-500">
          ©2025 Modern Attachment. All Rights Reserved.
        </div>
      </div>
    </footer>
  )
}