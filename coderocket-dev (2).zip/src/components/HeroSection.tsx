import { Button } from './ui/button'

export function HeroSection() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-8">
        <div className="inline-block bg-blue-900 text-white px-8 py-3 rounded-lg text-xl font-bold mb-6">
          FIND OUT IF THEY ARE ON DATING APPS
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-blue-900 mb-8">
          Discover The Truth Instantly With Our FAST & FREE Private Search.
        </h1>
      </div>

      <div className="flex flex-col lg:flex-row items-center justify-center gap-8 max-w-6xl mx-auto">
        <div className="flex-1 max-w-md">
          <img 
            src="https://staticlanderlab.com/variants/unpublished/1aa6ddc4fbc5604c9780831e9d160d2e/45df745f-90c7-45d4-0588-48bd037e7600.webp"
            alt="People at table illustration"
            className="w-full h-auto"
          />
        </div>

        <div className="flex-1 max-w-md">
          <div className="bg-blue-900 rounded-lg p-6 text-white">
            <h2 className="text-xl font-bold text-teal-300 mb-4">No More Guessing.</h2>
            <p className="mb-6 text-sm leading-relaxed">
              Want to see if they are secretly on dating apps? Our private search scans 120+ apps for secret profiles.
            </p>
            <p className="mb-6 text-sm">
              Enter their name, email, or phone number below to find out now
            </p>
            <Button className="w-full bg-teal-400 hover:bg-teal-500 text-black font-bold py-3 text-lg rounded-lg mb-3">
              CHECK NOW
            </Button>
            <p className="text-xs text-center text-gray-300">
              100% private, takes just 30 seconds
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}