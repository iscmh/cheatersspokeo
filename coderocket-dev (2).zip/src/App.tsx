import { HeroSection } from './components/HeroSection'
import { HowItWorksSection } from './components/HowItWorksSection'
import { FinalCTASection } from './components/FinalCTASection'
import { Footer } from './components/Footer'

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-200 to-sky-300">
      <HeroSection />
      <HowItWorksSection />
      <FinalCTASection />
      <Footer />
    </div>
  )
}

export default App